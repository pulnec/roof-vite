import { useState } from 'react'
import './App.css'
import ControlComponent from './component/ControlComponent/ControlComponent'
import Counter from './component/Counter/Counter'
import RoofComponent from './component/RoofComponent/RoofComponent'
import { evtRoof } from './utils/functions'

function App() {

  const [activeCounter, setActiveCounter] = useState(false);
  const [timeRoof, setTimeRoof] = useState(0); 

  const roofEvent = (seconds) => {
    setActiveCounter(true);
    setTimeRoof(seconds);
    evtRoof('open');
  }

  const finishEvent = () => {
    setActiveCounter(false);
    setTimeRoof(0);
    evtRoof('none');
  }

  return (
    <main>
      <div className="mb-4">
        <h3 className="text-2xl font-bold">Roof</h3>
      </div>
      <RoofComponent/>
      <ControlComponent onEventRoof={roofEvent}/>
      {activeCounter && <Counter timeRoof={timeRoof} onFinish={finishEvent} />}
    </main>
  )
}

export default App
